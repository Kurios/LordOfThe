package regex;
/*** At its lowest level, a REFragment represents every acceptable 
 *   
 * @author Kurios
 *
 */

public class REFragment {
		public REFragment(String s)
		{
			
		}
}
