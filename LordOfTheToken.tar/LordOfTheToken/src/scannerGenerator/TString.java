package scannerGenerator;

public class TString {
	
	String display = "";
	
	public TString(String s)
	{
		display = s;
	}
	
	public String display() throws Exception
	{
		return display;
	}
	
	public String toString()
	{
		return display;
	}
}
