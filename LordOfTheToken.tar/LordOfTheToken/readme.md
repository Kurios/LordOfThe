Three Tokens for the Elven-kings under the sky,

Seven for the Dwarf-lords in their halls of stone,

Nine for Mortal Men doomed to die,

One for the Dark Lord on his dark throne

In the Land of Mordor where the Shadows lie.

One Tokenizer to rule them all, One Tokenizer to find them,

One Tokenizer to bring them all and in the darkness bind them

In the Land of Mordor where the Shadows lie.

 

Deliverables:
---------------
- [ ] Scanner Generator
- [ ] Test input files : lexical specifications that are input to scanner generator
- [ ] Output files : generated scanner tables (DFA) and the table-walker which will walk the DFA as per the table reading the input to generate tokens. 
- [ ] The driver program.
